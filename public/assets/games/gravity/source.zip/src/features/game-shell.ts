export const COLORS = { bg:'#001308', green:'#00cc66', cyan:'#83f7fb', white:'#e5eee8', dim:'#087c42', amber:'#ffd166', red:'#ff7272' };
export class GameShell {
  readonly canvas: HTMLCanvasElement;
  readonly ctx: CanvasRenderingContext2D;
  readonly status: HTMLElement;
  readonly controls: HTMLElement;
  running = false;
  private raf = 0;
  private last = 0;
  private abort = new AbortController();
  private releaseControls: (() => void)[] = [];
  onReset = () => {};
  constructor(readonly host: HTMLElement, help: string) {
    host.innerHTML = `<div class="module-toolbar"><span class="module-status" role="status">STANDBY</span><button class="module-button" data-play>START</button><button class="module-button" data-reset>RESTART</button></div><canvas class="game-canvas" width="640" height="360" tabindex="0" aria-label="Station training simulation"></canvas><div class="game-pad"></div><p class="module-help">${help}</p>`;
    this.canvas = host.querySelector('canvas')!; this.ctx = this.canvas.getContext('2d')!;
    this.status = host.querySelector('.module-status')!; this.controls = host.querySelector('.game-pad')!;
    host.querySelector('[data-play]')!.addEventListener('click', () => { this.setRunning(!this.running); this.canvas.focus(); });
    host.querySelector('[data-reset]')!.addEventListener('click', () => { this.onReset(); this.setRunning(true); this.canvas.focus(); });
    this.canvas.addEventListener('click', () => this.canvas.focus());
    document.addEventListener('visibilitychange', () => { if (document.hidden) this.setRunning(false); }, { signal: this.abort.signal });
  }
  setRunning(value: boolean) { this.running = value; this.host.querySelector('[data-play]')!.textContent = value ? 'PAUSE' : 'RESUME'; }
  message(text: string) { this.status.textContent = text; }
  keys(handler: (key: string, pressed: boolean, repeat: boolean) => void) {
    for (const kind of ['keydown','keyup'] as const) this.host.addEventListener(kind, event => {
      if ((event.target as HTMLElement).matches('select,input')) return;
      const key = event.key.toLowerCase();
      if (!['arrowup','arrowdown','arrowleft','arrowright',' ','w','a','s','d','r','p','enter'].includes(key)) return;
      event.preventDefault(); event.stopPropagation();
      if (kind === 'keydown' && key === 'p' && !event.repeat) this.setRunning(!this.running);
      else handler(key, kind === 'keydown', event.repeat);
    }, { signal: this.abort.signal });
    this.host.addEventListener('focusout', () => { if (!this.host.contains(document.activeElement)) handler('release',false,false); }, { signal: this.abort.signal });
  }
  button(label: string, down: () => void, up: () => void = () => {}, repeat = false) {
    const b = document.createElement('button'); b.className = 'module-button'; b.textContent = label; this.controls.append(b);
    let timer = 0;
    const release = () => { clearInterval(timer); timer = 0; up(); b.setAttribute('aria-pressed','false'); };
    b.addEventListener('pointerdown', e => { e.preventDefault(); b.setPointerCapture(e.pointerId); b.setAttribute('aria-pressed','true'); this.canvas.focus(); down(); if(repeat) timer = window.setInterval(down,120); });
    b.addEventListener('pointerup',release); b.addEventListener('pointercancel',release); b.addEventListener('lostpointercapture',release);
    this.releaseControls.push(release);
  }
  loop(step: (dt: number) => void, draw: () => void) {
    const frame = (now: number) => {
      const dt = Math.min(0.06, Math.max(0, (now-this.last)/1000)); this.last = now;
      if(this.running) step(dt);
      draw(); this.raf = requestAnimationFrame(frame);
    };
    this.last=performance.now(); this.raf=requestAnimationFrame(frame);
  }
  clear() { this.ctx.fillStyle=COLORS.bg; this.ctx.fillRect(0,0,640,360); }
  text(text: string, x: number, y: number, color = COLORS.white, size = 16) { this.ctx.font=`${size}px Jix,monospace`; this.ctx.fillStyle=color; this.ctx.fillText(text,x,y); }
  dispose = () => { cancelAnimationFrame(this.raf); this.abort.abort(); this.releaseControls.forEach(release=>release()); };
}
